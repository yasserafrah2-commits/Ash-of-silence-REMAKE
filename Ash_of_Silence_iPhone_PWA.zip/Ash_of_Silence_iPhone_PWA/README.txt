ASH OF SILENCE REMAKE — IPHONE PWA PACKAGE

CONTENTS
- index.html: the game
- three.min.js: local Three.js library (no CDN needed)
- manifest.webmanifest: installable web-app settings
- sw.js: offline cache
- icons/: home-screen/app icons

IMPORTANT
1. Upload the CONTENTS of this folder to a website that serves HTTPS.
2. Open the HTTPS website in Safari on the iPhone.
3. Let the game finish loading once while online.
4. In Safari, tap Share > Add to Home Screen.
5. Launch it from the new home-screen icon. The service worker caches the game files for offline use.

You can create and store this folder/ZIP on your Samsung. An iPhone is only needed for the final Safari installation step.
The game itself has not been redesigned; this package only prepares the existing HTML and its Three.js dependency for PWA hosting.
